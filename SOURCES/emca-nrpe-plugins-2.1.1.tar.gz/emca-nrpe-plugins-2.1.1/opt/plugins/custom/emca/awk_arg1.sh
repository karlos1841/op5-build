/usr/bin/awk -F '|' '{print $1}'
