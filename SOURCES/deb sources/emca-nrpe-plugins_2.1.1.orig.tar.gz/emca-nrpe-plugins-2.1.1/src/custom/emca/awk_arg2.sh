/usr/bin/awk -F '|' '{print $2}'
